const colors= {
    primaryBackground: '#2ca33a',
    secondaryBackground: '#ffdd99',
    white: '#f5f5f5',
    black: '#000000'
}

export default colors